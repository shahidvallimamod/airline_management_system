<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="<?php echo e(route('airlines.update', $data->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <div>
        <label for="name">نام ایرلاین</label>
        <input type="text" name="name" value="<?php echo e($data->name); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div>
        <input type="submit" value="ذخیره">
    </div>
</form>

<form action="<?php echo e(route('airlines.destroy', $data->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
    <input type="submit" value="حذف">
</form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\amozeshgah\resources\views/airline/edit.blade.php ENDPATH**/ ?>