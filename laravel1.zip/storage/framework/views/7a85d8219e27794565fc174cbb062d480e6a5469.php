<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="<?php echo e(route('users.update', $data['id'])); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <label>نام کاربری</label>
    <input type="text" name="username" value="<?php echo e($data['name']); ?>">
    <label>پسوورد</label>
    <input type="password" name="password">
    <input type="submit">
</form>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\amozeshgah\resources\views/users/edit.blade.php ENDPATH**/ ?>