<?php

use Illuminate\Support\Facades\Route;

Route::resource('airlines',\App\Http\Controllers\AirlineController::class);
